// export const API_BASE_URL = process.env.REACT_APP_SERVER_URL;
export const API_BASE_URL = "https://gameplan-backend-7j9b.onrender.com";

export const getToken = () => localStorage.getItem("token");
